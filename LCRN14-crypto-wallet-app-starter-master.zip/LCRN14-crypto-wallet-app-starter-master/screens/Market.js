import React from 'react';
import {
    View,
    Text
} from 'react-native';

const Market = () => {
    return (
        <View>
            <Text>Market</Text>
        </View>
    )
}

export default Market;