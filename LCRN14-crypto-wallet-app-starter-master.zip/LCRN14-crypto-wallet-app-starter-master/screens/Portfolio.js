import React from 'react';
import {
    View,
    Text
} from 'react-native';

const Portfolio = () => {
    return (
        <View>
            <Text>Portfolio</Text>
        </View>
    )
}

export default Portfolio;